import networkx as nx
from experiment import Experiment as Experiment
import matplotlib.pyplot as plt

cfd_radius=0.3
omega=0.05
count = 1000

experiment = Experiment('data/uniform_20in100informed.graphml', cfd_radius=cfd_radius, omega=omega)

while count > 0:
    experiment.link()
    experiment.update()
    count -= 1

experiment.draw_thita1()
experiment.draw_thita2()


# experiment.draw_thita2()

# nx.write_graphml(experiment.G, 'end.graphml')
